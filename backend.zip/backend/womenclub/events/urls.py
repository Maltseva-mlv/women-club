# urls.py
from django.urls import path
from .views import get_events_for_date

urlpatterns = [

]
